Recoil-Runtime class dump - drop-in files (no patch, no edits to any of your files)

Install (archive paths line up with the repo):
  cd /path/to/Recoil-Runtime
  unzip -o /path/to/recoil-classdump-files.zip        # overwrites Sources/rcl_classdump.* etc.
  make package

Nothing else to apply: every file that is compiled already sits in your Makefile
(rcl_classdump.cpp) or is a header, and the stubs keep any Makefile state building.

Files:
  Sources/rcl_classdump.cpp  everything: table scan (strict + loose tier), per-class .md writer,
                             live per-tick writer (own pthread), diagnostics. Already in your Makefile.
  Sources/rcl_classdump.h    declarations: dump_class_tree / write_class_docs / live_docs_note / live_docs_flush
  Sources/rcl_docdata.h      reference data: 769 classes, 2090 methods (signature/mangled/size/hints)
  Sources/rcl_names.h        RVA -> Class::method (2090 entries)
  Sources/rcl_docgen.*       stub (include shim) so a Makefile that lists it still builds
  Sources/rcl_livedocs.*     stub (include shim) so a Makefile that lists it still builds

Output on device (Documents/RecoilDump/):
  <Category>/<Class>.md   one file per class, the reference format plus
                          Class Table (all slot RVAs) and Live ok/stale per method
  Unknown/vt_XXXXXX.md    every class table that no reference class claims
  _missing.md             what is NOT in the reference (tables without a class, unnamed slots, live-unknown vtables)
  _live/observed.md       realtime: every vtable seen on the heap, with states/hits/first tick
  _live/state_N.md        the same split per game state (lobby / battle / spectating)
  _live/anchors.md        the RVA chain worth keeping (home global, state/current/mgr offsets, ctrl)
  _diag.md                scanner diagnostics: strict vs loose tables, rejects, first bad candidate

Env knobs: RCL_DOCS=0 disables writing; RCL_DOCS_DIR=<dir> changes the root;
           RCL_CLASSES=full prints the old per-function log section.
